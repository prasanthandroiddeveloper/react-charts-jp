import { useEffect, useState } from "react";
import "./App.css";
import BarChart from "./components/BarChart";
import LineChart from "./components/LineChart";
import PieChart from "./components/PieChart";
import DoughnutChart from "./components/DoughnutChart";
import { UserData } from "./Data";
import { options } from "./Options"
import Axios from 'axios'

// import MultiChart from "./components/MultiChart";

function App() {
  const [dt, setDt] = useState([])
  useEffect(() => {
    Axios.get("https://gist.githubusercontent.com/prasanthandroiddeveloper/309551519379904bc9b1aed9e98145c6/raw/20d546aa9ad896fdda32aaa3dc86700bde3a79c3/UserData.json").then(res => {
      console.log(res.data.json())
      setDt(res.data.json())

    }).then((res) => {
      alert(res.data.json(), "skdjskodhksjhdkl")
    })
  });
  const [userData, setUserData] = useState({
    labels: UserData.map((data) => data.year),
    datasets: [
      {
        label: "Users Gained",
        data: UserData.map((data) => data.userGain),
        backgroundColor: [
          "rgba(75,192,192,1)",
          "#ecf0f1",
          "#50AF95",
          "#f3ba2f",
          "#2a71d0",
        ],
        borderColor: "blue",
        borderWidth: 1,
      },
    ],
  });

  // IF YOU SEE THIS COMMENT: I HAVE GOOD EYESIGHT

  return (
    <div>
      <div className="App" style={{ display: "flex" }}>
        <div style={{ width: 500 }}>
          <BarChart options={options} chartData={userData} />
        </div>
        <div style={{ width: 500, height: 300 }}>
          <LineChart options={options} chartData={userData} />
        </div>
      </div>
      <div style={{ display: "flex" }}>
        <div style={{ width: 500, height: 200 }}>
          <PieChart options={options} chartData={userData} />
        </div>
        <div style={{ width: 500 }}>
          <DoughnutChart options={options} chartData={userData} />
        </div>
        {/* <div style={{ width: 500 }}>
        <MultiChart chartData={userData} />
      </div> */}
      </div>
    </div>
  );
}

export default App;
